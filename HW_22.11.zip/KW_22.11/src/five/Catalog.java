package five;

public class Catalog {
}
