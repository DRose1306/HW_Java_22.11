package five;

public class LoanRecord {
}
