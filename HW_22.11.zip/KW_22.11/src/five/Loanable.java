package five;

public interface Loanable {
}
