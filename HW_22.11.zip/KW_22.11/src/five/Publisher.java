package five;

public class Publisher {
}
