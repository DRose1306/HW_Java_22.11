package five;

public interface Searchable {
}
