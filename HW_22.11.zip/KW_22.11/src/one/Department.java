package one;

public class Department implements DepartmentOperations{
    private String departmentName;
    private String[] employees;
    private int currentSize;
    private int maxSize;

    @Override
    public void addEmployee(Employee employee) {

    }

    @Override
    public void removeEmployee(String name) {

    }


    //3.7. Класс one.Department:
    //Поля: departmentName, массив employees, currentSize, maxSize.
    //Реализация интерфейса one.DepartmentOperations.
}
