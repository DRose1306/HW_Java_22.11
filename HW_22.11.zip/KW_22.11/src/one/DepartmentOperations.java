package one;

public interface DepartmentOperations {

    void addEmployee(Employee employee);

    void removeEmployee(String name);

    //3.6. Интерфейс one.DepartmentOperations:
    //Методы для управления сотрудниками отдела: addEmployee(one.Employee employee), removeEmployee(String name).
}
