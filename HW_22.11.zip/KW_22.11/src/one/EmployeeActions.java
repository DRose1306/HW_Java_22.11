package one;

public interface EmployeeActions {
    void work();
    void takeBreak();


    //3.1. Интерфейс one.EmployeeActions:
    //Определить методы для общих действий сотрудника, таких как work() и takeBreak().
}
