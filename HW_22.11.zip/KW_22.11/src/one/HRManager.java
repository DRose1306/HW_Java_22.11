package one;

public class HRManager extends Employee {
    private int numberOfRecruitments;
    private String[] candidateList;
    @Override
    public void work() {
        System.out.println("HR листает анкеты");
    }

    @Override
    public void takeBreak() {
        System.out.println("HR листает инстаграм");
    }

//3.5. Класс one.HRManager:
//Наследует one.Employee.
//Дополнительные поля: numberOfRecruitments, массив candidateList.
//Реализация методов work() и takeBreak() для HR-специалиста.
}
