package three;

public interface ControlInterface {
    //3.6. Интерфейс ControlInterface:
    //Методы для общего управления устройствами: turnOn(), turnOff(), getStatus().

    void turnOn();
    void turnOf();
    void getStatus();
}
