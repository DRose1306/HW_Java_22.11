package three;

public interface Security {
    //3.7. Интерфейс Security:
    //Методы для функций безопасности: armSystem(String code), disarmSystem(String code).
    void armSystem(String code);
    void isarmSystem(String code);
}
