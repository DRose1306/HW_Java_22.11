package two;

public interface Maintenance {
    //3.7. Интерфейс Maintenance:
    //Методы для обслуживания и ремонта транспортных средств.

    void vihicleCleaning();
    void checkVihicleCondition();
    void vihicleRepair();
    void commissioning();
}
