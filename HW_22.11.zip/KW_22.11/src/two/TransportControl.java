package two;

public interface TransportControl {
    //3.6. Интерфейс TransportControl:
    //Методы для управления движением и маршрутами транспортных средств.

    void vehicleRouteControl();
    void vehicleScheduleControl();
}
